# List entry for art

A Pen created on CodePen.io. Original URL: [https://codepen.io/jorge-fco/pen/gOrGXad](https://codepen.io/jorge-fco/pen/gOrGXad).

Ejemplo de listado para mostrar portafolio de trabajo.

Artista de Jalisco, México enfocado en el arte, diseños personalizados y murales.